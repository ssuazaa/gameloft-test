package com.susocode.gamelofttest.user.infrastructure.spring.implementation.output.client.campaignservice.dto;

import java.util.Set;

public record DoesNotHaveMatcherResponseDto(Set<String> items) {

}
