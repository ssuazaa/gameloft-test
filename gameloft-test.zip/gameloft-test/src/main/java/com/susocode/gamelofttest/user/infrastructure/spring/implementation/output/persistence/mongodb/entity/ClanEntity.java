package com.susocode.gamelofttest.user.infrastructure.spring.implementation.output.persistence.mongodb.entity;

public record ClanEntity(String id, String name) {

}
