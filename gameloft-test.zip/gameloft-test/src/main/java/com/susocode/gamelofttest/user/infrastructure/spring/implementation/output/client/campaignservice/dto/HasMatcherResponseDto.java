package com.susocode.gamelofttest.user.infrastructure.spring.implementation.output.client.campaignservice.dto;

import java.util.Set;

public record HasMatcherResponseDto(Set<String> country, Set<String> items) {

}
