package com.susocode.gamelofttest.user.infrastructure.spring.implementation.output.client.campaignservice.dto;

public record LevelMatcherResponseDto(int min, int max) {

}
