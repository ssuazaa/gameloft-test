package com.susocode.gamelofttest.user.infrastructure.spring.implementation.input.rest.dto;

public record ClanResponseDto(String id, String name) {

}
